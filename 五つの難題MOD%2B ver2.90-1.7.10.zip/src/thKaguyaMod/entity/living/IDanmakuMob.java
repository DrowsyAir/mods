package thKaguyaMod.entity.living;

public interface IDanmakuMob
{

    /**
     * 弾幕パターンの記述
     * @param level 弾幕難易度
     */
    void danmakuPattern(int level);
	
}
